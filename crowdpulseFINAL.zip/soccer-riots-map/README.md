# Soccer Riots Map

A single-page, real-world map of soccer riots, built with [Leaflet.js](https://leafletjs.com/) and OpenStreetMap tiles.

Click a marker on the map to open a detail view for that riot, with AI-fetched background information and a chat interface to ask follow-up questions about the event. The page also includes a contact section for reaching Rohan.

## Stack

- Plain HTML, CSS, and JavaScript — no frameworks, no build step, no bundler.
- [Leaflet.js](https://leafletjs.com/) loaded via CDN for the map.
- Two Node.js Netlify Functions (in `netlify/functions/`) to be added, powering the riot detail/chat and contact form.

## Structure

```
/
  index.html            single page: map, riot modal/chat, contact section
  css/style.css
  js/script.js
  data/riots.json        riot location data
  assets/
  netlify/functions/     serverless functions
  netlify.toml
  README.md
```
