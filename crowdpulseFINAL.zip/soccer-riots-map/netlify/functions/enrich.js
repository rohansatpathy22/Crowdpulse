// netlify/functions/enrich.js
//
// Netlify Function: enrich
//
// Given a riot's core fields (id/title/lat/lng, plus whatever other
// placeholder fields riots.json currently has), calls the Gemini API with
// Google Search grounding to research that specific real-world event, and
// returns rich, Wikipedia-style info in the shape the front end expects:
// { summary, description, causes, impact, images, sources }.
//
// The Gemini API key is read from process.env.GEMINI_API_KEY and is only
// ever used server-side here — it is never sent to the browser, included
// in any response body, or written to logs.
//
// Uses the Gemini Developer API's generateContent REST endpoint
// (v1beta), with Google Search grounding enabled via the `google_search`
// tool, per the current official Gemini API documentation:
// https://ai.google.dev/gemini-api/docs/generate-content/google-search
//
// Netlify Functions run on a Node.js runtime with a global `fetch`
// available (Node 18+), so no extra HTTP client dependency is needed.

const GEMINI_MODEL = 'gemini-3.6-flash';
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}

// Builds the research prompt for Gemini. The entire riotCoreFields object
// is passed through as-is (not just `title`) so that whatever additional
// placeholder fields exist (fieldA/fieldB/fieldC etc., soon to be renamed
// to real columns) are available as context, without this function having
// to know or assume their names.
function buildPrompt(riotCoreFields) {
  return `You are researching a specific real-world soccer riot / crowd violence incident for a factual, editorial reference site.

Here is what is currently known about this event (JSON object — some field names are placeholders and may not be descriptive):
${JSON.stringify(riotCoreFields, null, 2)}

Use Google Search to find real, verifiable information about this specific event. Do not guess or invent details. If you cannot confidently identify and find real information about this specific event, say so plainly in the "summary" field (e.g. "No verifiable information could be found for this event.") rather than inventing plausible-sounding details.

Respond with ONLY a single JSON object (no markdown code fences, no commentary before or after it), with exactly this shape:
{
  "summary": "A short 1-2 sentence summary of the event.",
  "description": "A longer, Wikipedia-style description of what happened.",
  "causes": "What led to or caused the incident.",
  "impact": "The aftermath and impact of the incident (injuries, deaths, arrests, policy changes, etc.), if known.",
  "images": ["direct image URLs, if any were found — this array may be empty"],
  "sources": [{"title": "Source title", "url": "https://..."}]
}`;
}

// Attempts to parse Gemini's text response as the expected JSON shape.
// Gemini is asked to return raw JSON, but may still wrap it in markdown
// code fences or add stray whitespace/text, so this strips common
// wrapping before parsing. Returns null if parsing fails.
function tryParseStructuredResponse(text) {
  if (!text) return null;

  let cleaned = text.trim();

  // Strip ```json ... ``` or ``` ... ``` code fences if present.
  const fenceMatch = cleaned.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (fenceMatch) {
    cleaned = fenceMatch[1].trim();
  }

  try {
    const parsed = JSON.parse(cleaned);
    if (parsed && typeof parsed === 'object') {
      return parsed;
    }
    return null;
  } catch (err) {
    return null;
  }
}

// Extracts grounding source links (title + url) from Gemini's grounding
// metadata, if present. These are the actual pages Google Search
// grounding used, so they're a reliable supplement/fallback for the
// `sources` field alongside whatever Gemini lists in its own JSON output.
function extractGroundingSources(candidate) {
  const chunks = candidate && candidate.groundingMetadata && candidate.groundingMetadata.groundingChunks;
  if (!Array.isArray(chunks)) return [];

  return chunks
    .map((chunk) => chunk && chunk.web)
    .filter((web) => web && web.uri)
    .map((web) => ({ title: web.title || web.uri, url: web.uri }));
}

exports.handler = async (event) => {
  // Only accept POST requests.
  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method Not Allowed. Use POST.' });
  }

  // Parse the JSON body.
  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (err) {
    return jsonResponse(400, { error: 'Request body must be valid JSON.' });
  }

  // riotCoreFields is treated as a generic object — we only rely on `title`
  // existing, since id/title/lat/lng are the only field names that are
  // structurally guaranteed right now. Other fields (fieldA/fieldB/fieldC
  // etc.) are placeholders and may be renamed later, so they are not
  // inspected individually — the whole object is passed into the prompt.
  const riotCoreFields = payload.riotCoreFields;

  if (!riotCoreFields || typeof riotCoreFields !== 'object') {
    return jsonResponse(400, { error: 'Missing required field: riotCoreFields.' });
  }

  if (!riotCoreFields.title || typeof riotCoreFields.title !== 'string') {
    return jsonResponse(400, { error: 'riotCoreFields.title is required.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    // Do not include any detail that could hint at key contents; this is
    // a server configuration problem, not a client error.
    console.error('enrich: GEMINI_API_KEY is not set.');
    return jsonResponse(500, { error: 'Server is not configured to reach the Gemini API.' });
  }

  const requestBody = {
    contents: [
      {
        parts: [{ text: buildPrompt(riotCoreFields) }],
      },
    ],
    tools: [{ google_search: {} }],
  };

  let geminiResponse;
  try {
    geminiResponse = await fetch(GEMINI_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify(requestBody),
    });
  } catch (err) {
    // Network-level failure calling Gemini. Log the error message only —
    // never the API key or the outgoing request.
    console.error('enrich: network error calling Gemini API:', err.message);
    return jsonResponse(502, { error: 'Failed to reach the Gemini API.' });
  }

  if (!geminiResponse.ok) {
    // Log status only. Avoid logging the full response body, since some
    // upstream error payloads can echo back parts of the request.
    console.error(`enrich: Gemini API returned ${geminiResponse.status} ${geminiResponse.statusText}`);
    return jsonResponse(502, { error: 'The Gemini API request failed.' });
  }

  let geminiData;
  try {
    geminiData = await geminiResponse.json();
  } catch (err) {
    console.error('enrich: failed to parse Gemini API response as JSON:', err.message);
    return jsonResponse(502, { error: 'Received an invalid response from the Gemini API.' });
  }

  const candidate = geminiData && geminiData.candidates && geminiData.candidates[0];
  const parts = candidate && candidate.content && candidate.content.parts;
  const rawText = Array.isArray(parts)
    ? parts.map((part) => part.text || '').join('')
    : '';

  const groundingSources = extractGroundingSources(candidate);
  const structured = tryParseStructuredResponse(rawText);

  let result;

  if (structured) {
    // Structured parsing succeeded — use Gemini's own fields, falling
    // back to safe defaults for anything missing, and supplement sources
    // with the grounding metadata (the actual pages grounding used) in
    // case Gemini's own "sources" list is thin or absent.
    const structuredSources = Array.isArray(structured.sources) ? structured.sources : [];
    const combinedSources = structuredSources.length > 0 ? structuredSources : groundingSources;

    result = {
      summary: typeof structured.summary === 'string' ? structured.summary : '',
      description: typeof structured.description === 'string' ? structured.description : '',
      causes: typeof structured.causes === 'string' ? structured.causes : '',
      impact: typeof structured.impact === 'string' ? structured.impact : '',
      // Images are best-effort: Google Search grounding often finds good
      // source pages but not always a clean, direct, hotlinkable image
      // URL, so this array may legitimately be empty. The front end
      // already handles an empty #riot-gallery gracefully.
      images: Array.isArray(structured.images) ? structured.images : [],
      sources: combinedSources,
    };
  } else {
    // Structured parsing failed — fall back to putting the raw text into
    // `description` rather than crashing or losing the response entirely.
    result = {
      summary: '',
      description: rawText || 'No information could be generated for this event.',
      causes: '',
      impact: '',
      images: [],
      sources: [],
    };
  }

  return jsonResponse(200, result);
};