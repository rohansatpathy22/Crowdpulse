// netlify/functions/chat.js
//
// Netlify Function: chat
//
// Given a riot's core fields, its previously-fetched enrichment data
// (summary/description/causes/impact), the user's new message, and the
// prior chat history, calls the Gemini API to answer follow-up questions
// about that specific riot — grounded in exactly what's already been
// shown to the user in the popup, so replies don't contradict it.
//
// The Gemini API key is read from process.env.GEMINI_API_KEY and is only
// ever used server-side here — it is never sent to the browser, included
// in any response body, or written to logs.
//
// Uses the Gemini Developer API's generateContent REST endpoint
// (v1beta), per the current official Gemini API documentation:
// https://ai.google.dev/gemini-api/docs/generate-content/get-started
// https://ai.google.dev/api/generate-content
//
// Netlify Functions run on a Node.js runtime with a global `fetch`
// available (Node 18+), so no extra HTTP client dependency is needed.

const GEMINI_MODEL = 'gemini-3.6-flash';
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}

// Builds the system instruction that grounds the conversation in this
// specific riot. Both riotCoreFields (whole object — field names besides
// id/title/lat/lng are still placeholders and not assumed) and
// riotEnrichment (the summary/description/causes/impact already shown to
// the user) are included, so the model answers consistently with what's
// already on screen rather than contradicting it.
function buildSystemInstruction(riotCoreFields, riotEnrichment) {
  return `You are answering follow-up questions about a specific real-world soccer riot / crowd violence incident, in a chat panel next to a popup that already shows the user some information about it.

Core event data (JSON — some field names are placeholders and may not be descriptive):
${JSON.stringify(riotCoreFields, null, 2)}

Information already shown to the user in the popup (JSON):
${JSON.stringify(riotEnrichment, null, 2)}

Answer the user's questions about this specific event, staying consistent with the information already shown above — do not contradict it. You may add reasonable additional detail if you're confident it's accurate, but if you don't know something or can't verify it, say so plainly rather than inventing details. Keep replies conversational and reasonably concise, as this is a chat interface, not an article.`;
}

// Converts our { role: 'user' | 'assistant', content: string } history
// entries into the Gemini `contents` format, which uses role "user" or
// "model" and a `parts` array.
function historyToContents(history) {
  return history
    .filter((entry) => entry && typeof entry.content === 'string')
    .map((entry) => ({
      role: entry.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: entry.content }],
    }));
}

exports.handler = async (event) => {
  // Only accept POST requests.
  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { error: 'Method Not Allowed. Use POST.' });
  }

  // Parse the JSON body.
  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (err) {
    return jsonResponse(400, { error: 'Request body must be valid JSON.' });
  }

  // riotCoreFields is treated as a generic object — we only rely on `title`
  // existing, since id/title/lat/lng are the only field names that are
  // structurally guaranteed right now. Other fields (fieldA/fieldB/fieldC
  // etc.) are placeholders and may be renamed later, so they are not
  // inspected individually — the whole object is passed into the prompt.
  const { riotCoreFields, riotEnrichment, message, history } = payload;

  if (!riotCoreFields || typeof riotCoreFields !== 'object') {
    return jsonResponse(400, { error: 'Missing required field: riotCoreFields.' });
  }

  if (!riotCoreFields.title || typeof riotCoreFields.title !== 'string') {
    return jsonResponse(400, { error: 'riotCoreFields.title is required.' });
  }

  if (!riotEnrichment || typeof riotEnrichment !== 'object') {
    return jsonResponse(400, { error: 'Missing required field: riotEnrichment.' });
  }

  if (!message || typeof message !== 'string') {
    return jsonResponse(400, { error: 'Missing required field: message.' });
  }

  if (!Array.isArray(history)) {
    return jsonResponse(400, { error: 'Missing or invalid required field: history (must be an array).' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    // Do not include any detail that could hint at key contents; this is
    // a server configuration problem, not a client error.
    console.error('chat: GEMINI_API_KEY is not set.');
    return jsonResponse(500, { error: 'Server is not configured to reach the Gemini API.' });
  }

  const requestBody = {
    system_instruction: {
      parts: [{ text: buildSystemInstruction(riotCoreFields, riotEnrichment) }],
    },
    contents: [
      ...historyToContents(history),
      { role: 'user', parts: [{ text: message }] },
    ],
  };

  let geminiResponse;
  try {
    geminiResponse = await fetch(GEMINI_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify(requestBody),
    });
  } catch (err) {
    // Network-level failure calling Gemini. Log the error message only —
    // never the API key or the outgoing request.
    console.error('chat: network error calling Gemini API:', err.message);
    return jsonResponse(502, { error: 'Failed to reach the Gemini API.' });
  }

  if (!geminiResponse.ok) {
    // Log status only. Avoid logging the full response body, since some
    // upstream error payloads can echo back parts of the request.
    console.error(`chat: Gemini API returned ${geminiResponse.status} ${geminiResponse.statusText}`);
    return jsonResponse(502, { error: 'The Gemini API request failed.' });
  }

  let geminiData;
  try {
    geminiData = await geminiResponse.json();
  } catch (err) {
    console.error('chat: failed to parse Gemini API response as JSON:', err.message);
    return jsonResponse(502, { error: 'Received an invalid response from the Gemini API.' });
  }

  const candidate = geminiData && geminiData.candidates && geminiData.candidates[0];
  const parts = candidate && candidate.content && candidate.content.parts;
  const replyText = Array.isArray(parts)
    ? parts.map((part) => part.text || '').join('').trim()
    : '';

  if (!replyText) {
    console.error('chat: Gemini API returned no reply text.');
    return jsonResponse(502, { error: 'The Gemini API did not return a reply.' });
  }

  return jsonResponse(200, { reply: replyText });
};